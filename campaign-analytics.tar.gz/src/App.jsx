import CampaignAnalytics from './CampaignAnalytics'
import './index.css'

function App() {
  return <CampaignAnalytics />
}

export default App
