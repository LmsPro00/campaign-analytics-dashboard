import React, { useState, useEffect } from 'react';
import { PlusCircle, TrendingUp, TrendingDown, Calendar, BarChart3, Download } from 'lucide-react';

const CampaignAnalytics = () => {
  const [campaigns, setCampaigns] = useState({});
  const [selectedCampaign, setSelectedCampaign] = useState('');
  const [newCampaignName, setNewCampaignName] = useState('');
  const [showNewCampaignInput, setShowNewCampaignInput] = useState(false);
  
  const [weekData, setWeekData] = useState({
    date: new Date().toISOString().split('T')[0],
    ctr: '',
    budget: '',
    crLanding: '',
    impressions: '',
    clicks: '',
    conversions: '',
    cpc: '',
    cpa: ''
  });

  useEffect(() => {
    const saved = localStorage.getItem('marketingCampaigns');
    if (saved) {
      const parsed = JSON.parse(saved);
      setCampaigns(parsed);
      if (Object.keys(parsed).length > 0) {
        setSelectedCampaign(Object.keys(parsed)[0]);
      }
    }
  }, []);

  useEffect(() => {
    if (Object.keys(campaigns).length > 0) {
      localStorage.setItem('marketingCampaigns', JSON.stringify(campaigns));
    }
  }, [campaigns]);

  const addNewCampaign = () => {
    if (newCampaignName.trim() && !campaigns[newCampaignName]) {
      setCampaigns({
        ...campaigns,
        [newCampaignName]: []
      });
      setSelectedCampaign(newCampaignName);
      setNewCampaignName('');
      setShowNewCampaignInput(false);
    }
  };

  const addWeekData = () => {
    if (!selectedCampaign) return;
    
    const newWeek = {
      ...weekData,
      weekNumber: campaigns[selectedCampaign].length + 1
    };
    
    setCampaigns({
      ...campaigns,
      [selectedCampaign]: [...campaigns[selectedCampaign], newWeek]
    });
    
    setWeekData({
      date: new Date().toISOString().split('T')[0],
      ctr: '',
      budget: '',
      crLanding: '',
      impressions: '',
      clicks: '',
      conversions: '',
      cpc: '',
      cpa: ''
    });
  };

  const calculateDelta = (current, previous) => {
    if (!previous || previous === 0) return null;
    const delta = ((current - previous) / previous) * 100;
    return delta.toFixed(2);
  };

  const currentCampaignData = selectedCampaign ? campaigns[selectedCampaign] || [] : [];
  
  const exportData = () => {
    const dataStr = JSON.stringify(campaigns, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'campagne-marketing.json';
    link.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <BarChart3 className="text-indigo-600" size={32} />
              <h1 className="text-3xl font-bold text-gray-800">Campaign Analytics Dashboard</h1>
            </div>
            <button
              onClick={exportData}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
            >
              <Download size={20} />
              Esporta Dati
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Seleziona Campagna
              </label>
              <select
                value={selectedCampaign}
                onChange={(e) => setSelectedCampaign(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-lg"
              >
                <option value="">-- Seleziona una campagna --</option>
                {Object.keys(campaigns).map(camp => (
                  <option key={camp} value={camp}>{camp}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Nuova Campagna
              </label>
              {!showNewCampaignInput ? (
                <button
                  onClick={() => setShowNewCampaignInput(true)}
                  className="w-full px-4 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition flex items-center justify-center gap-2"
                >
                  <PlusCircle size={20} />
                  Aggiungi Nuova Campagna
                </button>
              ) : (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newCampaignName}
                    onChange={(e) => setNewCampaignName(e.target.value)}
                    placeholder="Nome campagna..."
                    className="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                    onKeyPress={(e) => e.key === 'Enter' && addNewCampaign()}
                  />
                  <button
                    onClick={addNewCampaign}
                    className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
                  >
                    Crea
                  </button>
                  <button
                    onClick={() => {
                      setShowNewCampaignInput(false);
                      setNewCampaignName('');
                    }}
                    className="px-6 py-3 bg-gray-400 text-white rounded-lg hover:bg-gray-500 transition"
                  >
                    Annulla
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {selectedCampaign && (
          <>
            <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                <Calendar className="text-indigo-600" />
                Aggiungi Dati Settimanali - {selectedCampaign}
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Data</label>
                  <input
                    type="date"
                    value={weekData.date}
                    onChange={(e) => setWeekData({...weekData, date: e.target.value})}
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">CTR Medio (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={weekData.ctr}
                    onChange={(e) => setWeekData({...weekData, ctr: e.target.value})}
                    placeholder="es. 2.5"
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Budget Speso (€)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={weekData.budget}
                    onChange={(e) => setWeekData({...weekData, budget: e.target.value})}
                    placeholder="es. 500"
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">CR Landing (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={weekData.crLanding}
                    onChange={(e) => setWeekData({...weekData, crLanding: e.target.value})}
                    placeholder="es. 5.2"
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Impressioni</label>
                  <input
                    type="number"
                    value={weekData.impressions}
                    onChange={(e) => setWeekData({...weekData, impressions: e.target.value})}
                    placeholder="es. 10000"
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Click</label>
                  <input
                    type="number"
                    value={weekData.clicks}
                    onChange={(e) => setWeekData({...weekData, clicks: e.target.value})}
                    placeholder="es. 250"
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Conversioni</label>
                  <input
                    type="number"
                    value={weekData.conversions}
                    onChange={(e) => setWeekData({...weekData, conversions: e.target.value})}
                    placeholder="es. 13"
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">CPC Medio (€)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={weekData.cpc}
                    onChange={(e) => setWeekData({...weekData, cpc: e.target.value})}
                    placeholder="es. 2.00"
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">CPA (€)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={weekData.cpa}
                    onChange={(e) => setWeekData({...weekData, cpa: e.target.value})}
                    placeholder="es. 38.50"
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
              
              <button
                onClick={addWeekData}
                className="w-full px-6 py-4 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition flex items-center justify-center gap-2 text-lg font-semibold"
              >
                <PlusCircle size={24} />
                Salva Settimana {currentCampaignData.length + 1}
              </button>
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">
                Storico Settimane - {selectedCampaign}
              </h2>
              
              {currentCampaignData.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <BarChart3 size={64} className="mx-auto mb-4 opacity-30" />
                  <p className="text-lg">Nessun dato ancora inserito per questa campagna.</p>
                  <p className="text-sm">Aggiungi la prima settimana usando il form sopra.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-indigo-50 border-b-2 border-indigo-200">
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Settimana</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Data</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">CTR %</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Budget €</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">CR Landing %</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Impressioni</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Click</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Conversioni</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">CPC €</th>
                        <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">CPA €</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentCampaignData.map((week, index) => {
                        const prevWeek = index > 0 ? currentCampaignData[index - 1] : null;
                        
                        const renderCell = (value, prevValue, unit = '') => {
                          const delta = calculateDelta(parseFloat(value), parseFloat(prevValue));
                          const isPositive = delta > 0;
                          const isNegative = delta < 0;
                          
                          return (
                            <div>
                              <div className="font-semibold text-gray-800">
                                {value}{unit}
                              </div>
                              {delta !== null && (
                                <div className={`text-xs flex items-center gap-1 ${isPositive ? 'text-green-600' : isNegative ? 'text-red-600' : 'text-gray-500'}`}>
                                  {isPositive ? <TrendingUp size={14} /> : isNegative ? <TrendingDown size={14} /> : null}
                                  {isPositive ? '+' : ''}{delta}%
                                </div>
                              )}
                            </div>
                          );
                        };
                        
                        return (
                          <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                            <td className="px-4 py-4 font-bold text-indigo-600">W{week.weekNumber}</td>
                            <td className="px-4 py-4 text-gray-700">{new Date(week.date).toLocaleDateString('it-IT')}</td>
                            <td className="px-4 py-4">{renderCell(week.ctr, prevWeek?.ctr, '%')}</td>
                            <td className="px-4 py-4">{renderCell(week.budget, prevWeek?.budget, '€')}</td>
                            <td className="px-4 py-4">{renderCell(week.crLanding, prevWeek?.crLanding, '%')}</td>
                            <td className="px-4 py-4">{renderCell(week.impressions, prevWeek?.impressions)}</td>
                            <td className="px-4 py-4">{renderCell(week.clicks, prevWeek?.clicks)}</td>
                            <td className="px-4 py-4">{renderCell(week.conversions, prevWeek?.conversions)}</td>
                            <td className="px-4 py-4">{renderCell(week.cpc, prevWeek?.cpc, '€')}</td>
                            <td className="px-4 py-4">{renderCell(week.cpa, prevWeek?.cpa, '€')}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CampaignAnalytics;
